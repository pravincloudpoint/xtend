// export const Marathi = require('./Marathi.png'); 
export const English = require('./English.png'); 
// export const Hindi = require('./Hindi.png'); 
export const Science = require('./Science.png'); 


// export const Civics = require('./Civics.png'); 
export const Economics = require('./Economics.png'); 

export const Physics = require('./Physics.png'); 
// export const Chemestry = require('./Chemestry.png'); 
export const Biology = require('./Biology.png'); 
export const Mathematics = require('./Mathematics.png'); 

export const Geography = require('./Geography.png');
export const History = require('./History.png'); 

export const Computer = require('./Computer.png'); 
// export const Java = require('./Java.png'); 
// export const def = require('./Java.png'); 


// export const Environmental Science = require('./Environmental Science.png'); 
// export const Political Science = require('./Political Science.png'); 
// export const Continuity and Differentiability = require('./Continuity and Differentiability.png'); 